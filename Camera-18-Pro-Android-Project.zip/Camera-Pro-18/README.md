# Camera 18 Pro — Android project

This is an initial native Android camera app project using Kotlin, Jetpack Compose and CameraX.

## Current starter features
- Live rear-camera preview
- Photo capture and video recording
- Photo/video saving to the phone's `DCIM/Camera` gallery folder
- Camera zoom controls (the actual range depends on the phone camera hardware)
- Flash toggle and selectable camera modes in the interface
- Black premium interface with an iPhone-inspired shutter button

## Important limitations
This is a starter build, not a finished commercial camera app. Some displayed modes (Portrait, Night, Panorama, Live Photo, Slow Motion and Time Lapse) are currently interface selections and are not yet implemented as specialized capture pipelines. 4K/60 FPS, front-camera switching, manual focus, exposure, white balance, filters, voice shutter, Bluetooth shutter, horizon level, timestamps and watermark still need implementation and device testing. Actual camera features depend on the Vivo device's Camera2/CameraX hardware support.

The app has not been compiled or tested on a Vivo Y31 Pro 5G in this environment.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Camera 18 Pro APK** and tap **Run workflow** (or push to `main`).
4. Open the completed workflow run and download the `Camera-18-Pro-debug-apk` artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on the Android phone. Android may ask you to allow installation from that source.

A computer is usually easier for uploading the project, but GitHub's website can be used from a phone browser in desktop mode.
