package com.camerapro18

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.ZoomState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.VideoCapture
import androidx.camera.video.PendingRecording
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.text.SimpleDateFormat
import java.util.Locale

private val Black = Color(0xFF050505)
private val Gold = Color(0xFFFFC400)
private val White = Color.White
private val Grey = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent { CameraProScreen() }
    }
}

@Composable
fun CameraProScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var audioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermission = result[Manifest.permission.CAMERA] == true
        audioPermission = result[Manifest.permission.RECORD_AUDIO] == true
    }

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("PHOTO") }
    var zoom by remember { mutableFloatStateOf(1f) }
    var zoomMin by remember { mutableFloatStateOf(1f) }
    var zoomMax by remember { mutableFloatStateOf(1f) }
    var flashOn by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Ready") }

    fun bindCamera(view: PreviewView) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.surfaceProvider = view.surfaceProvider }
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.FHD))
                .build()
            val video = VideoCapture.withOutput(recorder)
            try {
                provider.unbindAll()
                val cam = provider.bindToLifecycle(
                    lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, video
                )
                camera = cam
                imageCapture = capture
                videoCapture = video
                cam.cameraInfo.zoomState.observe(lifecycleOwner) { state: ZoomState? ->
                    state?.let {
                        zoomMin = it.minZoomRatio
                        zoomMax = it.maxZoomRatio.coerceAtMost(30f)
                        zoom = it.zoomRatio.coerceIn(zoomMin, zoomMax)
                    }
                }
                capture.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                message = "Camera ready"
            } catch (e: Exception) {
                message = "Camera unavailable: ${e.localizedMessage ?: "error"}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) previewView?.let { bindCamera(it) }
    }

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().background(Black),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("CAMERA 18 PRO", color = White, fontSize = 16.sp)
                Text("18", color = Gold, fontSize = 18.sp)
                Text("⚙", color = White, fontSize = 22.sp)
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
                if (hasPermission) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).also {
                                it.scaleType = PreviewView.ScaleType.FILL_CENTER
                                previewView = it
                                bindCamera(it)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Camera permission required", color = White)
                        Button(onClick = {
                            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                        }) { Text("Allow camera") }
                    }
                }
                Text(message, color = White, modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp), fontSize = 11.sp)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("0.3x", "0.5x", "1x", "2x", "5x", "10x", "30x").forEach { label ->
                    val requested = label.removeSuffix("x").toFloat()
                    val enabled = requested >= zoomMin && requested <= zoomMax
                    Text(
                        label,
                        color = if (kotlin.math.abs(zoom - requested) < 0.15f) Gold else if (enabled) White else Grey,
                        modifier = Modifier.padding(horizontal = 7.dp).clickable(enabled = enabled) {
                            zoom = requested
                            camera?.cameraControl?.setZoomRatio(requested)
                        },
                        fontSize = 13.sp
                    )
                }
            }
            Slider(
                value = zoom.coerceIn(zoomMin, zoomMax),
                onValueChange = {
                    zoom = it
                    camera?.cameraControl?.setZoomRatio(it)
                },
                valueRange = zoomMin.coerceAtLeast(0.1f)..zoomMax.coerceAtLeast(zoomMin + 0.01f),
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold),
                modifier = Modifier.padding(horizontal = 22.dp)
            )

            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("PHOTO", "VIDEO", "PORTRAIT", "NIGHT", "SLOW MO", "TIME LAPSE", "PANO", "LIVE").forEach { item ->
                    Text(
                        item,
                        color = if (mode == item) Gold else Grey,
                        fontSize = 10.sp,
                        modifier = Modifier.clickable { mode = item }.padding(3.dp)
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(bottom = 26.dp, top = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("▣", color = White, fontSize = 28.sp)
                Box(
                    Modifier.size(76.dp).background(if (isRecording) Color.Red else White, CircleShape)
                        .padding(5.dp).background(Black, CircleShape)
                        .clickable {
                            if (!hasPermission) {
                                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                            } else if (mode == "VIDEO" || mode == "SLOW MO" || mode == "TIME LAPSE") {
                                if (isRecording) {
                                    recording?.stop()
                                    recording = null
                                    isRecording = false
                                } else {
                                    val vc = videoCapture
                                    if (vc == null) {
                                        message = "Video camera not ready"
                                    } else {
                                        val name = "Camera18Pro_${System.currentTimeMillis()}.mp4"
                                        val values = ContentValues().apply {
                                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                                            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                                            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/Camera")
                                        }
                                        val output = MediaStoreOutputOptions.Builder(
                                            context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                                        ).setContentValues(values).build()
                                        var pending: PendingRecording = vc.output.prepareRecording(context, output)
                                        if (audioPermission) pending = pending.withAudioEnabled()
                                        recording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
                                            if (event is VideoRecordEvent.Finalize) {
                                                isRecording = false
                                                message = if (event.hasError()) "Video save failed" else "Video saved"
                                            }
                                        }
                                        isRecording = true
                                        message = "Recording..."
                                    }
                                }
                            } else {
                                val capture = imageCapture
                                if (capture == null) {
                                    message = "Camera not ready"
                                } else {
                                    val name = "Camera18Pro_${System.currentTimeMillis()}.jpg"
                                    val values = ContentValues().apply {
                                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                                        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera")
                                    }
                                    val options = ImageCapture.OutputFileOptions.Builder(
                                        context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                                    ).build()
                                    capture.takePicture(options, ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageSavedCallback {
                                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                message = "Photo saved"
                                            }
                                            override fun onError(exception: ImageCaptureException) {
                                                message = "Photo failed: ${exception.message}"
                                            }
                                        })
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(58.dp).background(if (isRecording) Color.Red else White, CircleShape))
                }
                Text(if (flashOn) "⚡" else "ϟ", color = if (flashOn) Gold else White, fontSize = 28.sp,
                    modifier = Modifier.clickable {
                        flashOn = !flashOn
                        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                    })
            }
        }
    }
}
